import TrashIcon from './TrashIcon.vue'

export {
    TrashIcon
}
