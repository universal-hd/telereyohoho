import MovieList from './MovieList.vue'

export {
    MovieList
}
