import CardMovie from './CardMovie.vue'
import CardMovieSwipeWrapper from './CardMovieSwipeWrapper.vue'
import CardsMovieMainContent from './CardsMovieMainContent.vue'

export {
    CardMovie,
    CardMovieSwipeWrapper,
    CardsMovieMainContent
}

